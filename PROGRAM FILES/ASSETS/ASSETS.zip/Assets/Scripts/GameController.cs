using UnityEngine;
using UnityEngine.SceneManagement;  // Necesită acest namespace pentru a gestiona scenele
using TMPro;  // Pentru a gestiona textul UI

public class GameController : MonoBehaviour
{
    public GameObject winTextObject;  // Textul de "You Win!" sau "You Lose!"
    public GameObject restartButton;  // Referință la butonul de restart
    
    // Funcție de restart a jocului
    public void RestartGame()
    {
        // Resetează timpul, score-ul și alte variabile necesare
        Time.timeScale = 1;  // Restabilește timpul în caz că a fost oprit (în caz de pierdere)
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);  // Reîncarcă scena curentă
    }

    // Funcție pentru a opri jocul când se pierde
    public void GameOver()
    {
        Time.timeScale = 0;  // Oprește timpul (jocul se oprește când pierzi)
        winTextObject.SetActive(true);  // Afișează textul de înfrângere
        winTextObject.GetComponent<TextMeshProUGUI>().text = "YOU LOSE";

        // Afișează butonul de restart doar când pierzi
        restartButton.SetActive(true);
    }

    // Funcție pentru a afișa câștigul
    public void WinGame()
    {
        Time.timeScale = 0;  // Oprește timpul (jocul se oprește când câștigi)
        winTextObject.SetActive(true);  // Afișează textul de câștig
        winTextObject.GetComponent<TextMeshProUGUI>().text = "YOU WIN";

        // Afișează butonul de restart doar când câștigi
        restartButton.SetActive(true);
    }

    // Start is called before the first frame update
    void Start()
    {
        // La început, butonul de restart este dezactivat
        restartButton.SetActive(false);
        winTextObject.SetActive(false);  // La început, textul de câștig/perdere este ascuns
    }
}
