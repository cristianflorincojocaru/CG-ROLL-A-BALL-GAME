using UnityEngine;

public class PauseMenu : MonoBehaviour
{
    // Setează starea jocului
    private bool isPaused = false;

    // Referință la meniul de pauză (UI)
    public GameObject pauseMenuUI;

    // Start is called before the first frame update
    void Start()
    {
        // Asigură-te că meniul de pauză este ascuns la început
        pauseMenuUI.SetActive(true);  // Butonul de pauză va fi vizibil tot timpul
    }

    // Funcția care se apelează pentru a comuta starea pauzei
    public void TogglePause()
    {
        if (isPaused)
        {
            ResumeGame();
        }
        else
        {
            PauseGame();
        }
    }

    // Funcție pentru a pune jocul pe pauză
    void PauseGame()
    {
        Time.timeScale = 0f; // Oprește timpul în joc
        isPaused = true;
        pauseMenuUI.SetActive(true); // Arată meniul de pauză
    }

    // Funcție pentru a relua jocul
    void ResumeGame()
    {
        Time.timeScale = 1f; // Reia timpul în joc
        isPaused = false;
        pauseMenuUI.SetActive(false); // Ascunde meniul de pauză
    }

    // Funcție pentru a ieși din joc (dacă dorești să adaugi o opțiune de quit în pauză)
    public void QuitGame()
    {
        Debug.Log("Exiting Game...");
        Application.Quit(); // Închide aplicația
    }
}
