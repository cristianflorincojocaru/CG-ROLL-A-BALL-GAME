using UnityEngine;
using UnityEngine.InputSystem;
using TMPro;
using System.Collections;  // Adăugat pentru Coroutine

public class PlayerController : MonoBehaviour
{
    // Rigidbody of the player.
    private Rigidbody rb;

    // Variable to keep track of collected "PickUp" objects.
    private int count;

    // Movement along X and Y axes.
    private float movementX;
    private float movementY;

    // Speed at which the player moves.
    public float speed = 0;

    // UI text component to display count of "PickUp" objects collected.
    public TextMeshProUGUI countText;

    // UI object to display winning text.
    public GameObject winTextObject;

    // Timer variables
    public float timeRemaining = 90f;  // 1 minute and 30 seconds (90 seconds)
    public TextMeshProUGUI timerText;  // UI Text for the timer display

    // Jump variables
    public float jumpForce = 10f;  // Forța cu care mingea va sări
    private bool isGrounded;  // Verifică dacă mingea este pe sol

    // Referință la GameController pentru a apela metodele de câștig și pierdere
    public GameController gameController;

    // Referință la inamic (NoEnemy)
    public GameObject noEnemy;

    // Adăugăm o referință la scriptul PauseMenu
    public PauseMenu pauseMenu;  // Adăugăm această linie

    // Start is called before the first frame update.
    void Start()
    {
        // Get and store the Rigidbody component attached to the player.
        rb = GetComponent<Rigidbody>();

        // Initialize count to zero.
        count = 0;

        // Update the count display.
        SetCountText();

        // Initially set the win text to be inactive.
        winTextObject.SetActive(false);
    }

    // This function is called when a move input is detected.
    void OnMove(InputValue movementValue)
    {
        // Convert the input value into a Vector2 for movement.
        Vector2 movementVector = movementValue.Get<Vector2>();

        // Store the X and Y components of the movement.
        movementX = movementVector.x;
        movementY = movementVector.y;
    }

    // This function is called when jump input is detected.
    void OnJump(InputValue jumpValue)
    {
        if (isGrounded)  // Verificăm dacă mingea este pe sol
        {
            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);  // Aplicăm forța de salt
            isGrounded = false;  // După salt, setăm mingea ca fiind în aer
        }
    }

    // FixedUpdate is called once per fixed frame-rate frame.
    private void FixedUpdate()
    {
        // Verifică dacă jocul nu este în pauză
        if (Time.timeScale > 0)
        {
            // Create a 3D movement vector using the X and Y inputs.
            Vector3 movement = new Vector3(movementX, 0.0f, movementY);

            // Apply force to the Rigidbody to move the player.
            rb.AddForce(movement * speed);
        }

        // Timer countdown logic
        if (timeRemaining > 0)
        {
            timeRemaining -= Time.deltaTime;  // Decrease the time
            DisplayTime(timeRemaining);  // Update the timer display
        }
        else
        {
            // Time has run out, display "YOU LOSE !" message and stop the game
            if (!winTextObject.activeSelf) // Ensure it doesn't get overwritten by a previous win message
            {
                winTextObject.SetActive(true);
                winTextObject.GetComponent<TextMeshProUGUI>().text = "YOU LOSE !";
            }

            // Stop the game by setting time scale to 0
            Time.timeScale = 0;
            timeRemaining = 0; // Keep the time at 0

            // Call GameOver function to display the restart button
            gameController.GameOver();
        }
    }

    // Function to update the displayed count of "PickUp" objects collected.
    void SetCountText()
    {
        // Update the count text with the current count.
        countText.text = "cubes collected : " + count.ToString();

        // Check if the count has reached or exceeded the win condition.
        if (count >= 12)
        {
            // Display the win text.
            winTextObject.SetActive(true);

            // Destroy the enemy GameObject.
            Destroy(GameObject.FindGameObjectWithTag("Enemy"));

            // Call WinGame function to display the restart button
            gameController.WinGame();
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("PickUp"))
        {
            // Deactivate the "PickUp" object when collected.
            other.gameObject.SetActive(false);

            // Increment the count of collected cubes.
            count++;

            // Update the displayed count.
            SetCountText();
        }

        // Verifică dacă este pickup-ul "NoEnemy"
        if (other.gameObject.CompareTag("NoEnemy"))
        {
            // Deactivate the "NoEnemy" object when collected.
            other.gameObject.SetActive(false);

            // Dezactivează inamicul pentru 5 secunde
            StartCoroutine(DeactivateEnemyTemporarily());
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            // Destroy the player object upon collision with enemy.
            Destroy(gameObject);

            // Display "YOU LOSE !" message.
            winTextObject.gameObject.SetActive(true);
            winTextObject.GetComponent<TextMeshProUGUI>().text = "YOU LOSE !";

            // Stop the game by setting time scale to 0
            Time.timeScale = 0;

            // Call GameOver function to display the restart button
            gameController.GameOver();
        }
        else if (collision.gameObject.CompareTag("Ground"))
        {
            // Set the grounded flag to true when touching the ground
            isGrounded = true;
        }
    }

    // Function to format and display the timer
    void DisplayTime(float timeToDisplay)
    {
        float minutes = Mathf.FloorToInt(timeToDisplay / 60);  // Get minutes
        float seconds = Mathf.FloorToInt(timeToDisplay % 60);  // Get seconds

        timerText.text = string.Format("{0:00}:{1:00}", minutes, seconds);  // Format time for display
    }

    // Coroutine care dezactivează inamicul pentru 5 secunde
    private IEnumerator DeactivateEnemyTemporarily()
    {
        // Verifică dacă inamicul există
        if (noEnemy != null)
        {
            // Dezactivează inamicul
            noEnemy.SetActive(false);

            // Așteaptă 5 secunde
            yield return new WaitForSeconds(5);

            // Reactivați inamicul după 5 secunde
            noEnemy.SetActive(true);
        }
    }
}
